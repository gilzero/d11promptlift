//* THIS FILE IS AUTO-GENERATED. DO NOT EDIT.
import { I18n } from "../types";
import countryTranslations from "./countries.js";
import interfaceTranslations from "./interface.js";

export { countryTranslations, interfaceTranslations };

const allTranslations: I18n = { ...countryTranslations, ...interfaceTranslations };
export default allTranslations;
