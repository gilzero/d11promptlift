//* Korean. Translated by: Google Translate.
import { I18n } from "../types";

const interfaceTranslations: I18n = {
  selectedCountryAriaLabel: "선택한 국가",
  noCountrySelected: "선택한 국가가 없습니다.",
  countryListAriaLabel: "국가 목록",
  searchPlaceholder: "찾다",
  zeroSearchResults: "검색 결과가 없습니다",
  oneSearchResult: "검색된 결과 1개",
  multipleSearchResults: "${count}개의 결과를 찾았습니다.",
  
  // additional countries (not supported by country-list library)
  ac: "승천섬",
  xk: "코소보",
};

export default interfaceTranslations;