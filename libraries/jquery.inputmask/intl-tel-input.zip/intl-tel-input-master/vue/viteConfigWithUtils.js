import { getConfig } from "./viteConfig";

export default getConfig("IntlTelInputWithUtils.vue");